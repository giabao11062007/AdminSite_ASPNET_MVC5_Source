using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web.Mvc;
using AdminStore.Models;

namespace AdminStore.Areas.Admin.Controllers
{
    public class AccountController : Controller
    {
        private readonly AdminStoreEntities db = new AdminStoreEntities();

        public ActionResult Login() { return View(); }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Login(string username, string password)
        {
            if (String.IsNullOrWhiteSpace(username) || String.IsNullOrEmpty(password))
            {
                ViewBag.Error = "Vui lòng nhập tên đăng nhập và mật khẩu.";
                return View();
            }

            string hash = Sha256(password);
            var admin = db.AdminAccounts.FirstOrDefault(a =>
                a.Username == username && a.PasswordHash == hash && a.IsActive);

            if (admin == null)
            {
                ViewBag.Error = "Tên đăng nhập hoặc mật khẩu không đúng.";
                return View();
            }

            Session["AdminID"] = admin.AdminID;
            Session["AdminName"] = admin.FullName;
            return RedirectToAction("Index", "Home", new { area = "Admin" });
        }

        public ActionResult Logout()
        {
            Session.Remove("AdminID");
            Session.Remove("AdminName");
            return RedirectToAction("Login");
        }

        private static string Sha256(string input)
        {
            using (var sha = SHA256.Create())
            {
                var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(input));
                return String.Concat(bytes.Select(b => b.ToString("X2")));
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
