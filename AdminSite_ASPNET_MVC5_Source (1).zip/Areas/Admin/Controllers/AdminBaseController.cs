using System.Web.Mvc;

namespace AdminStore.Areas.Admin.Controllers
{
    // Bộ kiểm tra đăng nhập đơn giản phục vụ bài học.
    // Với website thật nên dùng ASP.NET Identity và [Authorize].
    public class AdminBaseController : Controller
    {
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (Session["AdminID"] == null)
            {
                filterContext.Result = new RedirectToRouteResult(
                    new System.Web.Routing.RouteValueDictionary(
                        new { area = "Admin", controller = "Account", action = "Login" }));
                return;
            }
            base.OnActionExecuting(filterContext);
        }
    }
}
