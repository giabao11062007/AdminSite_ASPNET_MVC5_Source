using System.Linq;
using System.Web.Mvc;
using AdminStore.Models;

namespace AdminStore.Areas.Admin.Controllers
{
    public class CustomersController : AdminBaseController
    {
        public ActionResult Index(string keyword)
        {
            using (var db = new AdminStoreEntities())
            {
                var query = db.Customers.AsQueryable();
                if (!string.IsNullOrWhiteSpace(keyword))
                    query = query.Where(c => c.FullName.Contains(keyword) ||
                        (c.Email != null && c.Email.Contains(keyword)) ||
                        (c.Phone != null && c.Phone.Contains(keyword)));
                ViewBag.Keyword = keyword;
                return View(query.OrderBy(c => c.FullName).ToList());
            }
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(400);
            using (var db = new AdminStoreEntities())
            {
                var customer = db.Customers.Find(id);
                if (customer == null) return HttpNotFound();
                return View(customer);
            }
        }
    }
}
