using System.Linq;
using System.Web.Mvc;
using AdminStore.Models;

namespace AdminStore.Areas.Admin.Controllers
{
    public class HomeController : AdminBaseController
    {
        public ActionResult Index()
        {
            using (var db = new AdminStoreEntities())
            {
                ViewBag.CategoryCount = db.Categories.Count();
                ViewBag.ProductCount = db.Products.Count();
                ViewBag.CustomerCount = db.Customers.Count();
                ViewBag.OrderCount = db.Orders.Count();
            }
            return View();
        }
    }
}
