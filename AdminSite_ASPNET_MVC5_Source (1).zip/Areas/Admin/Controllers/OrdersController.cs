using System.Linq;
using System.Web.Mvc;
using AdminStore.Models;

namespace AdminStore.Areas.Admin.Controllers
{
    public class OrdersController : AdminBaseController
    {
        public ActionResult Index(string status)
        {
            using (var db = new AdminStoreEntities())
            {
                var query = db.Orders.Include("Customer").AsQueryable();
                if (!string.IsNullOrWhiteSpace(status)) query = query.Where(o => o.Status == status);
                ViewBag.Status = status;
                return View(query.OrderByDescending(o => o.OrderDate).ToList());
            }
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(400);
            using (var db = new AdminStoreEntities())
            {
                var order = db.Orders.Include("Customer").Include("OrderDetails.Product")
                    .FirstOrDefault(o => o.OrderID == id);
                if (order == null) return HttpNotFound();
                return View(order);
            }
        }
    }
}
