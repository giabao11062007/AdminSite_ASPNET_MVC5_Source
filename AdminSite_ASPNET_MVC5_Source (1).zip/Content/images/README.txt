Lưu ảnh sản phẩm tại thư mục này. Tạo thêm file no-image.png làm ảnh mặc định hoặc sửa ProductImage trong SQL để dùng ảnh có sẵn.
