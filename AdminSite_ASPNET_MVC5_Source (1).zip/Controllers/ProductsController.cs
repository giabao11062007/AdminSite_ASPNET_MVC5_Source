using System;
using System.IO;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using AdminStore.Models;

namespace AdminStore.Controllers
{
    public class ProductsController : Controller
    {
        private readonly AdminStoreEntities db = new AdminStoreEntities();
        private const int PageSize = 5;

        public ActionResult Index(string keyword, decimal? minPrice, decimal? maxPrice, string sortOrder, int page = 1)
        {
            var query = db.Products.Include("Category").AsQueryable();

            if (!String.IsNullOrWhiteSpace(keyword))
            {
                keyword = keyword.Trim();
                query = query.Where(p => p.ProductName.Contains(keyword) ||
                    (p.ProductDescription != null && p.ProductDescription.Contains(keyword)) ||
                    p.Category.CategoryName.Contains(keyword));
            }
            if (minPrice.HasValue) query = query.Where(p => p.ProductPrice >= minPrice.Value);
            if (maxPrice.HasValue) query = query.Where(p => p.ProductPrice <= maxPrice.Value);

            switch (sortOrder)
            {
                case "name_desc": query = query.OrderByDescending(p => p.ProductName); break;
                case "price_asc": query = query.OrderBy(p => p.ProductPrice); break;
                case "price_desc": query = query.OrderByDescending(p => p.ProductPrice); break;
                default: query = query.OrderBy(p => p.ProductName); break;
            }

            int total = query.Count();
            int totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)PageSize));
            page = Math.Max(1, Math.Min(page, totalPages));

            var vm = new ProductSearchVM
            {
                Keyword = keyword,
                MinPrice = minPrice,
                MaxPrice = maxPrice,
                SortOrder = sortOrder,
                Page = page,
                PageSize = PageSize,
                TotalItems = total,
                Products = query.Skip((page - 1) * PageSize).Take(PageSize).ToList()
            };
            return View(vm);
        }

        public ActionResult Details(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var product = db.Products.Include("Category").FirstOrDefault(p => p.ProductID == id);
            if (product == null) return HttpNotFound();
            return View(product);
        }

        public ActionResult Create()
        {
            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName");
            return View(new Product());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (product.UploadImg == null) ModelState.Remove("UploadImg");
            if (ModelState.IsValid)
            {
                SaveImage(product);
                product.CreatedAt = DateTime.Now;
                db.Products.Add(product);
                db.SaveChanges();
                TempData["Message"] = "Đã thêm sản phẩm.";
                return RedirectToAction("Index");
            }
            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var product = db.Products.Find(id);
            if (product == null) return HttpNotFound();
            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            if (product.UploadImg == null) ModelState.Remove("UploadImg");
            if (ModelState.IsValid)
            {
                var existing = db.Products.Find(product.ProductID);
                if (existing == null) return HttpNotFound();
                existing.CategoryID = product.CategoryID;
                existing.ProductName = product.ProductName;
                existing.ProductDescription = product.ProductDescription;
                existing.ProductPrice = product.ProductPrice;
                if (product.UploadImg != null && product.UploadImg.ContentLength > 0)
                {
                    product.ProductImage = existing.ProductImage;
                    SaveImage(product);
                    existing.ProductImage = product.ProductImage;
                }
                db.SaveChanges();
                TempData["Message"] = "Đã cập nhật sản phẩm.";
                return RedirectToAction("Index");
            }
            ViewBag.CategoryID = new SelectList(db.Categories, "CategoryID", "CategoryName", product.CategoryID);
            return View(product);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var product = db.Products.Include("Category").FirstOrDefault(p => p.ProductID == id);
            if (product == null) return HttpNotFound();
            return View(product);
        }

        [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var product = db.Products.Find(id);
            if (product == null) return HttpNotFound();
            if (db.OrderDetails.Any(d => d.ProductID == id))
            {
                TempData["Message"] = "Không thể xóa sản phẩm đã nằm trong đơn hàng.";
                return RedirectToAction("Index");
            }
            db.Products.Remove(product);
            db.SaveChanges();
            TempData["Message"] = "Đã xóa sản phẩm.";
            return RedirectToAction("Index");
        }

        private void SaveImage(Product product)
        {
            if (product.UploadImg == null || product.UploadImg.ContentLength <= 0) return;
            var extension = Path.GetExtension(product.UploadImg.FileName);
            var allowed = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
            if (!allowed.Contains((extension ?? "").ToLowerInvariant()))
                throw new InvalidOperationException("Chỉ chấp nhận ảnh JPG, PNG, GIF hoặc WEBP.");
            string folder = Server.MapPath("~/Content/images");
            if (!Directory.Exists(folder)) Directory.CreateDirectory(folder);
            string fileName = Guid.NewGuid().ToString("N") + extension.ToLowerInvariant();
            product.UploadImg.SaveAs(Path.Combine(folder, fileName));
            product.ProductImage = "~/Content/images/" + fileName;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
