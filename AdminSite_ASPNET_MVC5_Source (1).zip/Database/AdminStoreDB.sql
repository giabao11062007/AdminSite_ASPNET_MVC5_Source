IF DB_ID(N'AdminStoreDB') IS NULL
    CREATE DATABASE AdminStoreDB;
GO
USE AdminStoreDB;
GO

IF OBJECT_ID('dbo.OrderDetail','U') IS NOT NULL DROP TABLE dbo.OrderDetail;
IF OBJECT_ID('dbo.Orders','U') IS NOT NULL DROP TABLE dbo.Orders;
IF OBJECT_ID('dbo.Product','U') IS NOT NULL DROP TABLE dbo.Product;
IF OBJECT_ID('dbo.Category','U') IS NOT NULL DROP TABLE dbo.Category;
IF OBJECT_ID('dbo.Customer','U') IS NOT NULL DROP TABLE dbo.Customer;
IF OBJECT_ID('dbo.AdminAccount','U') IS NOT NULL DROP TABLE dbo.AdminAccount;
GO

CREATE TABLE dbo.Category (
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL
);
CREATE TABLE dbo.Product (
    ProductID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryID INT NOT NULL,
    ProductName NVARCHAR(200) NOT NULL,
    ProductDescription NVARCHAR(1000) NULL,
    ProductPrice DECIMAL(18,2) NOT NULL CHECK (ProductPrice >= 0),
    ProductImage NVARCHAR(260) NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_Product_Category FOREIGN KEY (CategoryID) REFERENCES dbo.Category(CategoryID)
);
CREATE TABLE dbo.AdminAccount (
    AdminID INT IDENTITY(1,1) PRIMARY KEY,
    Username NVARCHAR(50) NOT NULL UNIQUE,
    PasswordHash NVARCHAR(64) NOT NULL,
    FullName NVARCHAR(100) NOT NULL,
    IsActive BIT NOT NULL DEFAULT 1
);
CREATE TABLE dbo.Customer (
    CustomerID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(150) NULL,
    Phone NVARCHAR(20) NULL,
    Address NVARCHAR(300) NULL,
    CreatedAt DATETIME NOT NULL DEFAULT GETDATE()
);
CREATE TABLE dbo.Orders (
    OrderID INT IDENTITY(1,1) PRIMARY KEY,
    CustomerID INT NOT NULL,
    OrderDate DATETIME NOT NULL DEFAULT GETDATE(),
    Status NVARCHAR(30) NOT NULL DEFAULT N'Mới đặt',
    TotalAmount DECIMAL(18,2) NOT NULL DEFAULT 0,
    CONSTRAINT FK_Orders_Customer FOREIGN KEY (CustomerID) REFERENCES dbo.Customer(CustomerID)
);
CREATE TABLE dbo.OrderDetail (
    OrderDetailID INT IDENTITY(1,1) PRIMARY KEY,
    OrderID INT NOT NULL,
    ProductID INT NOT NULL,
    Quantity INT NOT NULL CHECK (Quantity > 0),
    UnitPrice DECIMAL(18,2) NOT NULL CHECK (UnitPrice >= 0),
    CONSTRAINT FK_OrderDetail_Order FOREIGN KEY (OrderID) REFERENCES dbo.Orders(OrderID),
    CONSTRAINT FK_OrderDetail_Product FOREIGN KEY (ProductID) REFERENCES dbo.Product(ProductID)
);
GO

INSERT dbo.Category(CategoryName) VALUES
(N'Burger'), (N'Pizza'), (N'Gà rán'), (N'Đồ uống');
INSERT dbo.Product(CategoryID, ProductName, ProductDescription, ProductPrice, ProductImage) VALUES
(1,N'Burger bò phô mai',N'Burger bò, phô mai và rau tươi',59000,N'~/Content/images/no-image.png'),
(1,N'Burger gà giòn',N'Gà giòn cùng sốt đặc biệt',49000,N'~/Content/images/no-image.png'),
(2,N'Pizza xúc xích',N'Pizza xúc xích phô mai',99000,N'~/Content/images/no-image.png'),
(3,N'Gà rán 2 miếng',N'Gà rán giòn bên ngoài, mềm bên trong',65000,N'~/Content/images/no-image.png'),
(4,N'Trà chanh',N'Trà chanh mát lạnh',20000,N'~/Content/images/no-image.png');

INSERT dbo.Customer(FullName,Email,Phone,Address) VALUES
(N'Nguyễn Minh Anh',N'minhanh@example.com',N'0900000001',N'TP. Hồ Chí Minh'),
(N'Trần Quốc Bảo',N'quocbao@example.com',N'0900000002',N'TP. Hồ Chí Minh');

INSERT dbo.Orders(CustomerID,OrderDate,Status,TotalAmount) VALUES
(1,GETDATE(),N'Mới đặt',118000),
(2,GETDATE(),N'Đang xử lý',99000);
INSERT dbo.OrderDetail(OrderID,ProductID,Quantity,UnitPrice) VALUES
(1,1,2,59000),
(2,3,1,99000);

-- Tài khoản demo: admin / Admin@123
-- SHA256("Admin@123") = E86F78A8A3CAF0B60D8E74E5942AA6D86DC150CD3C03338AEF25B7D2D7E3ACC7
INSERT dbo.AdminAccount(Username,PasswordHash,FullName,IsActive)
VALUES (N'admin',N'E86F78A8A3CAF0B60D8E74E5942AA6D86DC150CD3C03338AEF25B7D2D7E3ACC7',N'Quản trị viên',1);
GO
