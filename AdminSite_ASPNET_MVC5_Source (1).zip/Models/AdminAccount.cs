using System.ComponentModel.DataAnnotations;

namespace AdminStore.Models
{
    public class AdminAccount
    {
        [Key]
        public int AdminID { get; set; }

        [Required, StringLength(50)]
        public string Username { get; set; }

        [Required, StringLength(64)]
        public string PasswordHash { get; set; }

        [Required, StringLength(100)]
        public string FullName { get; set; }

        public bool IsActive { get; set; }
    }
}
