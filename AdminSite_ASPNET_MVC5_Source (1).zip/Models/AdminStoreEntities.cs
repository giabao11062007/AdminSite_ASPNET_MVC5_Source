using System.Data.Entity;

namespace AdminStore.Models
{
    public class AdminStoreEntities : DbContext
    {
        public AdminStoreEntities() : base("name=AdminStoreEntities")
        {
            // Database được tạo bằng script SQL đi kèm, không để EF tự tạo lại schema.
            Database.SetInitializer<AdminStoreEntities>(null);
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<AdminAccount> AdminAccounts { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderDetail> OrderDetails { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            // Map đúng tên bảng số ít đã tạo trong Database/AdminStoreDB.sql
            modelBuilder.Entity<Category>().ToTable("Category");
            modelBuilder.Entity<Product>().ToTable("Product");
            modelBuilder.Entity<AdminAccount>().ToTable("AdminAccount");
            modelBuilder.Entity<Customer>().ToTable("Customer");
            modelBuilder.Entity<Order>().ToTable("Orders");
            modelBuilder.Entity<OrderDetail>().ToTable("OrderDetail");

            modelBuilder.Entity<Product>()
                .Property(p => p.ProductPrice).HasPrecision(18, 2);
            modelBuilder.Entity<Order>()
                .Property(o => o.TotalAmount).HasPrecision(18, 2);
            modelBuilder.Entity<OrderDetail>()
                .Property(d => d.UnitPrice).HasPrecision(18, 2);

            base.OnModelCreating(modelBuilder);
        }
    }
}
