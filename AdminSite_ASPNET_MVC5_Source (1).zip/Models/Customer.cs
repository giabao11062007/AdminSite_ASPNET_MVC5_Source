using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace AdminStore.Models
{
    public class Customer
    {
        [Key] public int CustomerID { get; set; }
        [Required, StringLength(100)] [Display(Name = "Họ tên")] public string FullName { get; set; }
        [StringLength(150)] [Display(Name = "Email")] public string Email { get; set; }
        [StringLength(20)] [Display(Name = "Số điện thoại")] public string Phone { get; set; }
        [StringLength(300)] [Display(Name = "Địa chỉ")] public string Address { get; set; }
        [Display(Name = "Ngày tạo")] public DateTime CreatedAt { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
    }
}
