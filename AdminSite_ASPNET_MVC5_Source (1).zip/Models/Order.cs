using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdminStore.Models
{
    [Table("Orders")]
    public class Order
    {
        [Key] public int OrderID { get; set; }
        [Required] public int CustomerID { get; set; }
        [Display(Name = "Ngày đặt")] public DateTime OrderDate { get; set; }
        [StringLength(30)] [Display(Name = "Trạng thái")] public string Status { get; set; }
        [Display(Name = "Tổng tiền")] public decimal TotalAmount { get; set; }
        public virtual Customer Customer { get; set; }
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }

    public class OrderDetail
    {
        [Key] public int OrderDetailID { get; set; }
        [Required] public int OrderID { get; set; }
        [Required] public int ProductID { get; set; }
        [Range(1, 10000)] public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public virtual Order Order { get; set; }
        public virtual Product Product { get; set; }
    }
}
