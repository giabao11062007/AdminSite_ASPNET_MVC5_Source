using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Web;

namespace AdminStore.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Required(ErrorMessage = "Vui lòng chọn danh mục.")]
        [Display(Name = "Danh mục")]
        public int CategoryID { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập tên sản phẩm.")]
        [StringLength(200)]
        [Display(Name = "Tên sản phẩm")]
        public string ProductName { get; set; }

        [StringLength(1000)]
        [Display(Name = "Mô tả")]
        public string ProductDescription { get; set; }

        [Required(ErrorMessage = "Vui lòng nhập giá.")]
        [Range(0, 999999999, ErrorMessage = "Giá phải lớn hơn hoặc bằng 0.")]
        [Display(Name = "Giá")]
        public decimal ProductPrice { get; set; }

        [Display(Name = "Đường dẫn ảnh")]
        public string ProductImage { get; set; }

        [Display(Name = "Ngày tạo")]
        public DateTime CreatedAt { get; set; }

        [NotMapped]
        [Display(Name = "Chọn ảnh")]
        public HttpPostedFileBase UploadImg { get; set; }

        public virtual Category Category { get; set; }
    }
}
