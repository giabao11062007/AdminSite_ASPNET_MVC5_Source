using System.Collections.Generic;
using System.Web.Mvc;

namespace AdminStore.Models
{
    public class ProductSearchVM
    {
        public string Keyword { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public string SortOrder { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalItems { get; set; }
        public List<Product> Products { get; set; }
        public IEnumerable<SelectListItem> Categories { get; set; }
    }
}
