ADMIN SITE - ASP.NET MVC 5 + Entity Framework 6 + SQL Server
============================================================

LƯU Ý QUAN TRỌNG
- Gói này là bộ source để đưa vào một project ASP.NET Web Application (.NET Framework) dùng ASP.NET MVC 5.
- Không phải ASP.NET Core MVC.
- Dùng Entity Framework 6, SQL Server và .NET Framework (nên dùng .NET Framework 4.7.2 hoặc 4.8).
- Các file được chia theo đúng cấu trúc MVC. Không thể đặt toàn bộ code MVC vào một file duy nhất.
- Vì chưa có cấu trúc project/database thực tế của bạn, tên database mặc định là AdminStoreDB. Hãy chỉnh connection string nếu cần.

CÁCH LÀM TRÊN VISUAL STUDIO
1. Mở Visual Studio -> Create a new project.
2. Chọn "ASP.NET Web Application (.NET Framework)" -> chọn .NET Framework 4.8.
3. Chọn template MVC.
4. Cài NuGet package: EntityFramework (6.x), nếu project chưa có.
5. Chép các thư mục Controllers, Models, Views, Areas và Content trong gói này vào project. Nếu đã có file trùng tên, hãy so sánh trước khi ghi đè.
6. Mở SQL Server Management Studio (SSMS), chạy file Database/AdminStoreDB.sql.
7. Mở Web.config ở gốc project và thêm/cập nhật connection string theo mẫu dưới đây:
   <connectionStrings>
     <add name="AdminStoreEntities"
          connectionString="Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=AdminStoreDB;Integrated Security=True;MultipleActiveResultSets=True"
          providerName="System.Data.SqlClient" />
   </connectionStrings>
   Nếu dùng SQL Server instance khác, thay Data Source bằng tên server của bạn.
8. Trong Models, kiểm tra namespace. Bộ source dùng namespace AdminStore.Models; nếu tên project khác, đổi namespace và các using tương ứng.
9. Build -> Build Solution. Sửa lỗi namespace nếu tên project của bạn khác.
10. Chạy website bằng Ctrl+F5.
11. Trang danh mục: /Categories
    Trang sản phẩm: /Products
    Đăng nhập Admin: /Admin/Account/Login
    Quản lý khách hàng: /Admin/Customers
    Quản lý đơn hàng: /Admin/Orders

TÀI KHOẢN ADMIN MẪU
- Tên đăng nhập: admin
- Mật khẩu: Admin@123
- Đây là tài khoản demo cho bài tập. Không dùng mật khẩu này cho website thật.
- Mật khẩu demo được lưu dạng hash SHA256 trong SQL. Cần thay đổi khi triển khai thực tế.

CÁC CHỨC NĂNG CÓ TRONG GÓI
- Admin Layout dùng chung.
- Category: danh sách, chi tiết, tạo, sửa, xóa.
- Product: danh sách, tìm kiếm, lọc khoảng giá, sắp xếp, phân trang, chi tiết, tạo/sửa/xóa, upload ảnh.
- Admin: đăng nhập/đăng xuất demo.
- Customer: danh sách và chi tiết.
- Orders: danh sách đơn hàng và chi tiết.
- SQL tạo bảng Category, Product, AdminAccount, Customer, Orders, OrderDetail và dữ liệu mẫu.

PHẠM VI / ĐIỂM CẦN HOÀN THIỆN
- Phần quản lý Admin Account dạng CRUD đầy đủ chưa được bật trong giao diện; đăng nhập demo được cung cấp để bạn chạy và trình bày luồng Admin.
- Chức năng thanh toán và giao diện Customer không thuộc phần Admin Site này.
- Bảo mật đăng nhập đang ở mức minh họa bài học, chưa thay thế ASP.NET Identity. Không triển khai công khai khi chưa gia cố bảo mật.
- Nếu project của bạn đã có Model/DbContext được sinh từ database bằng Database First, không chép đè chúng ngay; gửi ảnh cấu trúc project để điều chỉnh chính xác.
